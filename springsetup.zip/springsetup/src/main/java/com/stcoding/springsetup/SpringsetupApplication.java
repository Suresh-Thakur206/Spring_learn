package com.stcoding.springsetup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsetupApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsetupApplication.class, args);
	}

}
