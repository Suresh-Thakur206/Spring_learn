package com.stcoding.springsetup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsetupApplicationTests {

	@Test
	void contextLoads() {
	}

}
