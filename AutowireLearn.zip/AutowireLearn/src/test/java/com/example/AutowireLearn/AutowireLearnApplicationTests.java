package com.example.AutowireLearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutowireLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
