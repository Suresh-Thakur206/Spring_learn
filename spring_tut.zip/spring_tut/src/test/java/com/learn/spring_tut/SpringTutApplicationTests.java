package com.learn.spring_tut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTutApplicationTests {

	@Test
	void contextLoads() {
	}

}
